# Artist Next.js Starter (Code only)

## Lancer en local
npm install
npm run dev

## Déployer sur Netlify
- Import from Git
- Build: npm run build
- Publish: .next
- Variables: NODE_VERSION=20 (recommandé)

## Contenu
- Next.js 14 (App Router)
- Tailwind + thème clair/sombre
- Galerie (sans œuvres) + pages /oeuvre/[slug]
- Contact (Netlify Forms)
- Sitemap & robots
- CMS Decap/Netlify CMS (admin/)
